// import java.util.Scanner;
// import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
// import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

// public class StopHits2 extends Thread implements NativeKeyListener {

//     public static Scanner sc = new Scanner(System.in);
//     public static String stop = "HitMe!";

//     @Override
//     public void run() {
//         while (!stop.equals("")) {
//             stop = sc.next();
//         }
//         System.out.println("\nThank you!");
//     }

//     public void nativeKeyTyped(NativeKeyEvent e) {//dont know how to implement 

//     }

//     public static void main(String[] args) {
//         StopHits2 hitMet = new StopHits2();
//         hitMet.start();

//         while (!stop.equals("")) {

//             System.out.print(stop);
//             try {
//                 Thread.sleep(200);
//             } catch (InterruptedException e) {
//                 e.printStackTrace();
//             }
//         }

//         sc.close();
//     }

// }